part of 'post_bloc.dart';

abstract class PostEvent {}

class PostLoadEvent extends PostEvent {}
